const DMP_PAGE_URL = "https://dmp.taobao.com/index_new.html";
const MODEL_LIST_FILTER = { urls: ["https://dmp.taobao.com/api_2/ai/assistant/model/list*"] };
const HEARTBEAT_ALARM = "selection-tool-dmp-heartbeat";

let syncInFlight = null;
let lastSyncUrl = "";
let lastSyncAt = 0;
const redirectedRequestIds = new Set();

async function readConfig() {
  return chrome.storage.local.get(["apiBaseUrl", "extensionToken", "userName", "lastStatus", "lastSyncAt", "lastError"]);
}

async function apiRequest(path, method = "GET", body) {
  const config = await readConfig();
  if (!config.apiBaseUrl || !config.extensionToken) throw new Error("扩展尚未绑定选品工具。");
  const response = await fetch(`${config.apiBaseUrl}${path}`, {
    method,
    cache: "no-store",
    headers: {
      Authorization: `Bearer ${config.extensionToken}`,
      ...(body === undefined ? {} : { "Content-Type": "application/json" }),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = Array.isArray(data.message) ? data.message.join("；") : data.message;
    throw new Error(message || `选品工具 API 返回 HTTP ${response.status}`);
  }
  return data;
}

async function setBadge(status) {
  const settings = {
    VALID: { text: "OK", color: "#15803d" },
    INVALID: { text: "!", color: "#dc2626" },
    ERROR: { text: "…", color: "#d97706" },
    WAITING_FOR_LOGIN: { text: "…", color: "#d97706" },
    NOT_PAIRED: { text: "", color: "#64748b" },
  };
  const value = settings[status] || settings.ERROR;
  await chrome.action.setBadgeText({ text: value.text });
  await chrome.action.setBadgeBackgroundColor({ color: value.color });
}

async function notify(id, title, message) {
  await chrome.notifications.create(id, {
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message,
    priority: 2,
  });
}

async function reportState(status, message) {
  try {
    await apiRequest("/api/dmp/extension/report", "POST", { status, message });
  } catch {
    // 网络不可用时不记录令牌或 Cookie，也不把网络异常误判为登录过期。
  }
  await chrome.storage.local.set({ lastStatus: status, lastError: status === "VALID" ? null : message || null });
  await setBadge(status);
}

async function markLoginInvalid(message) {
  const previous = await readConfig();
  const wasInvalid = previous.lastStatus === "INVALID";
  await reportState("INVALID", message);
  if (!wasInvalid) {
    await notify("dmp-login-invalid", "达摩盘登录已失效", "请打开达摩盘重新登录。登录成功后，扩展会自动更新授权。");
  } else {
    await notify("dmp-login-invalid", "达摩盘需要重新登录", "请打开达摩盘重新登录，选品工具的 AI 管家任务会等待授权恢复。");
  }
}

async function captureAndSync(requestUrl) {
  if (syncInFlight) return syncInFlight;
  const now = Date.now();
  if (requestUrl === lastSyncUrl && now - lastSyncAt < 30000) return;
  syncInFlight = (async () => {
    const config = await readConfig();
    if (!config.extensionToken || !config.apiBaseUrl) {
      await setBadge("NOT_PAIRED");
      return;
    }
    const parsed = new URL(requestUrl);
    if (parsed.origin !== "https://dmp.taobao.com" || parsed.pathname !== "/api_2/ai/assistant/model/list") return;
    const [cookies, gatewayCookies] = await Promise.all([
      chrome.cookies.getAll({ url: DMP_PAGE_URL }),
      chrome.cookies.getAll({ url: "https://dmp.advgateway.taobao.com/" }),
    ]);
    const cookieHeader = cookies.map((cookie) => `${cookie.name}=${cookie.value}`).join("; ");
    const gatewayCookieHeader = gatewayCookies.map((cookie) => `${cookie.name}=${cookie.value}`).join("; ");
    if (!cookieHeader) {
      await markLoginInvalid("浏览器没有读取到达摩盘登录 Cookie，请重新登录达摩盘。");
      return;
    }
    try {
      await apiRequest("/api/dmp/extension/credentials", "PUT", {
        requestUrl: parsed.toString(),
        cookieHeader,
        ...(gatewayCookieHeader ? { gatewayCookieHeader } : {}),
        userAgent: navigator.userAgent,
      });
      lastSyncUrl = requestUrl;
      lastSyncAt = Date.now();
      const wasInvalid = config.lastStatus === "INVALID";
      await chrome.storage.local.set({ lastStatus: "VALID", lastSyncAt: new Date().toISOString(), lastError: null });
      await setBadge("VALID");
      if (wasInvalid) await notify("dmp-login-restored", "达摩盘登录已恢复", "登录状态已自动更新，可以继续使用选品工具。");
    } catch (error) {
      const message = error instanceof Error ? error.message : "授权同步失败。";
      await reportState("ERROR", message.slice(0, 180));
      await notify("dmp-sync-error", "达摩盘授权同步失败", "请打开扩展查看状态；不要手动复制 Cookie。");
    }
  })().finally(() => { syncInFlight = null; });
  return syncInFlight;
}

async function heartbeat() {
  const config = await readConfig();
  if (!config.extensionToken) return;
  try {
    const result = await apiRequest("/api/dmp/extension/heartbeat");
    const status = result.lastStatus || "NOT_CONFIGURED";
    await chrome.storage.local.set({ lastStatus: status, lastSyncAt: result.lastSyncAt || config.lastSyncAt || null, lastError: result.lastError || null });
    await setBadge(status === "NOT_CONFIGURED" ? "WAITING_FOR_LOGIN" : status);
    if (status === "INVALID") {
      await notify("dmp-login-invalid", "达摩盘登录已失效", "请打开达摩盘重新登录。登录成功后，扩展会自动更新授权。");
    }
  } catch (error) {
    if (error instanceof Error && /扩展授权已过期|扩展授权无效/.test(error.message)) {
      await chrome.storage.local.remove(["apiBaseUrl", "extensionToken", "userName"]);
      await chrome.storage.local.set({ lastStatus: "NOT_PAIRED", lastError: "扩展授权已过期，请重新配对。" });
      await setBadge("NOT_PAIRED");
      await notify("dmp-extension-expired", "选品工具扩展授权已过期", "请回到选品工具的达摩盘授权页重新配对扩展。");
    }
  }
}

chrome.webRequest.onCompleted.addListener((details) => {
  if (redirectedRequestIds.has(details.requestId)) {
    redirectedRequestIds.delete(details.requestId);
    return;
  }
  if (details.statusCode === 401 || details.statusCode === 403) {
    void markLoginInvalid(`达摩盘 model/list 返回 HTTP ${details.statusCode}。`);
    return;
  }
  const contentType = (details.responseHeaders || []).find((header) => header.name.toLowerCase() === "content-type")?.value || "";
  if (contentType.toLowerCase().includes("text/html")) {
    void markLoginInvalid("达摩盘 model/list 返回了登录页面内容，请重新登录。");
    return;
  }
  if (details.statusCode >= 200 && details.statusCode < 300) void captureAndSync(details.url);
}, MODEL_LIST_FILTER, ["responseHeaders"]);

chrome.webRequest.onBeforeRedirect.addListener((details) => {
  redirectedRequestIds.add(details.requestId);
  let redirectLooksLikeLogin = false;
  try {
    const target = new URL(details.redirectUrl);
    redirectLooksLikeLogin = /(^|\.)login\.taobao\.com$|(^|\.)login\.tmall\.com$/i.test(target.hostname) || /login|passport|signin/i.test(target.pathname);
  } catch {
    redirectLooksLikeLogin = true;
  }
  if (redirectLooksLikeLogin) void markLoginInvalid("达摩盘请求被重定向到登录页面，登录状态可能已失效。");
  else void reportState("ERROR", "达摩盘 model/list 请求发生了非登录重定向，请检查页面状态。");
}, MODEL_LIST_FILTER);

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === HEARTBEAT_ALARM) void heartbeat();
});

chrome.notifications.onClicked.addListener((notificationId) => {
  if (notificationId.startsWith("dmp-login") || notificationId === "dmp-extension-expired") {
    void chrome.tabs.create({ url: DMP_PAGE_URL });
  }
});

chrome.runtime.onInstalled.addListener(() => {
  void chrome.alarms.create(HEARTBEAT_ALARM, { periodInMinutes: 15 });
  void heartbeat();
});

chrome.runtime.onStartup.addListener(() => {
  void chrome.alarms.create(HEARTBEAT_ALARM, { periodInMinutes: 15 });
  void heartbeat();
});
